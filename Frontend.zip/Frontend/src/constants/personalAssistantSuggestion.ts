export const personalAssistantSuggestion = [
    "Show patient history",
    'Create prescription',
    'Help me diagnose',
    'Clinical support',
    'Medical terminologies',
    'Review patient case',
    'Show latest developments'
]