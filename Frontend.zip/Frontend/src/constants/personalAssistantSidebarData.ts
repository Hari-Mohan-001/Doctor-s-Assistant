export const personalAssistantSideBarData = [
    {
        id:1,
        title:"Today",
        search1:"New Enquiry",
        search2:"Create prescription for Mr.Emil"
    },
    {
        id:2,
        title:"Yesterday",
        search1:"Create prescription for Mr.Arun",
        search2:"Create prescription for Mr.Emil"
    },
    {
        id:3,
        title:"Last 7 days",
        search1:"Create prescription for Mr.Sanu",
        search2:"Create prescription for Mr.Emil"
    },
    {
        id:4,
        title:"Last 30 days",
        search1:"Create prescription for Mr.Ajin",
        search2:"Create prescription for Mr.Emil"
    },
    {
        id:5,
        title:"Last 3 months",
        search1:"Create prescription for Mr.Dipu",
        search2:"Create prescription for Mr.Emil"
    },
]