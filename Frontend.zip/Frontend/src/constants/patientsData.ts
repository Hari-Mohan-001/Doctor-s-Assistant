export const patientData = [
         {
            name:"Arun",
            age:"32 Years",
            gender:"M",
            condition:"He is having a better condition in case of health and fitness",
            medications:"Prscribed for regular use of vitamin tablets and exercises.",
            status: "open"
         },
         {
            name:"Afreed",
            age:"29 Years",
            gender:"M",
            condition:"He is having a better condition in case of health and fitness",
            medications:"Prscribed for regular use of vitamin tablets and exercises.",
            status: "close"
         },
         {
            name:"Jeena",
            age:"28 Years",
            gender:"F",
            condition:"He is having a better condition in case of health and fitness",
            medications:"Prscribed for regular use of vitamin tablets and exercises.",
            status: "open"
         },
         {
            name:"Shain",
            age:"26 Years",
            gender:"M",
            condition:"He is having a better condition in case of health and fitness",
            medications:"Prscribed for regular use of vitamin tablets and exercises.",
            status: "close"
         }
]