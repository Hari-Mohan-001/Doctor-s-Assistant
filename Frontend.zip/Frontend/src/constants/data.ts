export const userEmail = "doctor@gmail.com"
 export const userPassword = "doctor@123"
