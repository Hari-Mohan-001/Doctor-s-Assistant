import DoctorRoutes from "./routes/DoctorRoutes";

function App() {
  return (
    <>
      <DoctorRoutes />
    </>
  );
}

export default App;
